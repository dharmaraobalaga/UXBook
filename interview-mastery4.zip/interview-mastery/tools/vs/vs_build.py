import json, pathlib
ROOT = pathlib.Path('/home/claude/interview-mastery')
def fig(k, alt, te, en): return f'!fig:assets/images/vs/{k}.svg|{alt}|{te}|{en}'

Q1_TE = f"""User Flow (యూజర్ ఫ్లో) మరియు User Journey (యూజర్ జర్నీ) రెండూ UX Designలో చాలా ముఖ్యమైనవి. కానీ వీటి ఉద్దేశాలు వేర్వేరు.
సింపుల్‌గా చెప్పాలంటే:
- User Flow: యూజర్ ఒక పనిని పూర్తి చేయడానికి ఏయే స్టెప్స్ ద్వారా వెళ్తాడు?
- User Journey: ఒక ప్రోడక్ట్‌ను ఉపయోగిస్తున్నప్పుడు యూజర్‌కు మొదటి నుంచి చివరి వరకు ఎలాంటి అనుభవం ఎదురవుతుంది?

### 1 · User Flow
User Flow అంటే ఏమిటి?

User Flow అంటే ఒక నిర్దిష్టమైన పనిని (Task) పూర్తి చేయడానికి యూజర్ అనుసరించే దశల క్రమం.
యూజర్ ఎక్కడ ప్రారంభిస్తాడు? ఏ బటన్ క్లిక్ చేస్తాడు? తర్వాత ఏ స్క్రీన్‌కు వెళ్తాడు? చివరకు తన పని ఎలా పూర్తి చేస్తాడు? అనే విషయాలను చూపిస్తుంది.

{fig('vs-login-flow', 'Login user flow: Open App, Login Screen, Enter Mobile Number, OTP Verification, Home Screen', 'ఉదాహరణ: Classic Rummy Appలో యూజర్ Login అవ్వడం – యాప్ ఓపెన్ చేయడం → లాగిన్ స్క్రీన్ → మొబైల్ నంబర్ నమోదు → OTP ధృవీకరణ → లాగిన్ విజయవంతం.', 'Example: user login in the Classic Rummy app.')}

ఇక్కడ యూజర్ ఒక నిర్దిష్టమైన పని అయిన Login పూర్తి చేయడానికి అనుసరించే స్టెప్స్‌ను చూపించాం.

User Flow ప్రధానంగా దేనిపై దృష్టి పెడుతుంది?:
- Screen-to-screen navigation
- User actions
- Decision points
- Task completion
- Error and alternative paths

### 2 · User Journey
User Journey అంటే ఏమిటి?

User Journey అంటే ఒక ప్రోడక్ట్ లేదా సర్వీస్‌ను ఉపయోగించే క్రమంలో యూజర్‌కు ఎదురయ్యే మొత్తం అనుభవం.
యూజర్‌కు ప్రోడక్ట్ గురించి ఎలా తెలుస్తుంది? ఎందుకు ఉపయోగించాలనుకుంటాడు? ఎక్కడ ఇబ్బంది పడతాడు? అతనికి ఎలాంటి భావనలు కలుగుతాయి? చివరకు సంతృప్తి చెందుతాడా? అనే అంశాలను వివరిస్తుంది.

{fig('vs-journey', 'User journey with five stages: Awareness, Consideration, Registration, First Game, Retention', 'ఉదాహరణ: Classic Rummy Appలో కొత్త యూజర్ అనుభవం – 5 దశలు; ప్రతి దశ తెలుగు వివరణ క్రింద ఉంది.', 'Example: a new user’s experience in the Classic Rummy app.')}

ఉదాహరణ: Classic Rummy Appలో కొత్త యూజర్ అనుభవం:
1. Awareness – పరిచయం: యూజర్ ఒక ప్రకటన ద్వారా Classic Rummy App గురించి తెలుసుకుంటాడు. (Positive) “ఈ యాప్ బాగుంది, ఒకసారి ప్రయత్నించాలి.”
2. Consideration – ఆలోచన: యాప్‌ను డౌన్‌లోడ్ చేయాలా వద్దా అని ఆలోచిస్తాడు. రేటింగ్స్, ఫీచర్లు చూస్తాడు. (Uncertain) “ఇది నమ్మదగిన యాప్‌నా?”
3. Registration – నమోదు: యాప్ ఓపెన్ చేసి మొబైల్ నంబర్, OTP ద్వారా రిజిస్టర్ అవుతాడు. (Possible Friction) “రిజిస్ట్రేషన్ సులభంగా ఉందా?”
4. First Game – మొదటి గేమ్: గేమ్ ఎలా ఆడాలో తెలుసుకుని మొదటి గేమ్ ఆడతాడు. (Engaged) “గేమ్ ఆడటం ఆసక్తికరంగా ఉంది.”
5. Retention – మళ్లీ ఉపయోగించడం: మంచి అనుభవం ఉంటే యూజర్ తిరిగి యాప్ ఓపెన్ చేసి ఆడతాడు. (Satisfied) “ఈ యాప్ మళ్లీ ఉపయోగించాలి.”

User Journey ప్రధానంగా దేనిపై దృష్టి పెడుతుంది?:
- User Goals and Expectations
- User Emotions
- Pain Points
- Touchpoints
- Overall Experience
- Opportunities for Improvement

### 3 · User Flow vs User Journey
తేడా ఏమిటి?

అంశం\tUser Flow\tUser Journey
అర్థం\tపని పూర్తి చేసే దశలు\tమొత్తం యూజర్ అనుభవం
ప్రధాన దృష్టి\tActions & Navigation\tExperience & Emotions
పరిధి\tఒక నిర్దిష్టమైన Task\tమొత్తం అనుభవం
చూపించేది\tScreens, Steps, Decisions\tStages, Goals, Pain Points
ఉపయోగం\tTask సులభతరం చేయడానికి\tమొత్తం అనుభవాన్ని మెరుగుపరచడానికి
ఉదాహరణ\tLogin ఎలా చేయాలి?\tయాప్ గురించి తెలుసుకున్నప్పటి నుంచి మళ్లీ ఉపయోగించే వరకు అనుభవం

### 4 · ఎప్పుడు ఉపయోగించాలి?
రెండింటినీ ఎప్పుడు ఉపయోగించాలి?

User Flow: ఒక Taskను యూజర్ సులభంగా పూర్తి చేయగలడా అని తెలుసుకోవడానికి.

{fig('vs-wireflow', 'User flow of screens for a first app launch, with a first-launch decision, onboarding, sign-up and home', 'User Flow – screens, actions, decision point (First launch?) మరియు alternative path.', 'User Flow: screens, actions, a decision point and an alternative path.')}

User Journey: యూజర్‌కు మొత్తం ప్రోడక్ట్ అనుభవం ఎలా ఉందో తెలుసుకోవడానికి.

{fig('vs-journey-map', 'Journey map grid with five stages and five layers: actions, goals, feelings, pain points, opportunities', 'User Journey Map – దశలు (Awareness → Loyalty) × actions, goals, feelings, pain points, opportunities.', 'Journey map: stages × actions, goals, feelings, pain points and opportunities.')}

### 5 · ఇంటర్వ్యూలో ఎలా చెప్పాలి?
Question: What is the difference between User Flow and User Journey?

మీరు ఇలా సింపుల్‌గా చెప్పవచ్చు:
“User Flow focuses on the steps a user takes to complete a specific task in a product. For example, logging into an app or making a payment.
User Journey focuses on the complete user experience, including their goals, expectations, emotions, and pain points across different stages.
In simple words, User Flow explains how users complete a task, while User Journey explains what users experience throughout their interaction with the product.”

Remember this:
- User Flow = How the user completes a task.
- User Journey = What the user experiences throughout the process.

ఈ రెండింటినీ కలిపి ఉపయోగించినప్పుడు యూజర్‌కు ఎదురయ్యే సమస్యలను గుర్తించి, మెరుగైన UX Design రూపొందించగలుగుతాము."""

Q1_EN = f"""User Flow and User Journey are both very important in UX design, but their purposes are different.
Put simply:
- User Flow: which steps does a user go through to complete a task?
- User Journey: what experience does the user have from start to finish while using a product?

### 1 · User Flow
What is a User Flow?

A User Flow is the sequence of steps a user follows to complete a specific task.
It shows where the user starts, which button they click, which screen they go to next and how they finally complete the task.

{fig('vs-login-flow', 'Login user flow', '', 'Example: user login in the Classic Rummy app – Open App → Login Screen → Enter Mobile Number → OTP Verification → Home Screen.')}

Here we show the steps a user follows to complete one specific task: login.

What does a User Flow mainly focus on?:
- Screen-to-screen navigation
- User actions
- Decision points
- Task completion
- Error and alternative paths

### 2 · User Journey
What is a User Journey?

A User Journey is the complete experience a user has while using a product or service.
It explains how the user learns about the product, why they want to use it, where they struggle, what they feel and whether they are finally satisfied.

{fig('vs-journey', 'User journey with five stages', '', 'Example: a new user’s experience in the Classic Rummy app.')}

Example – a new user’s experience in the Classic Rummy app:
1. Awareness: the user learns about the Classic Rummy app through an advertisement. (Positive) “This app looks good, I should try it once.”
2. Consideration: thinks about whether to download it; checks ratings and features. (Uncertain) “Is this a trustworthy app?”
3. Registration: opens the app and registers with a mobile number and OTP. (Possible friction) “Is registration easy?”
4. First Game: learns how to play and plays the first game. (Engaged) “Playing the game is interesting.”
5. Retention: with a good experience, the user opens the app again and plays. (Satisfied) “I should use this app again.”

What does a User Journey mainly focus on?:
- User goals and expectations
- User emotions
- Pain points
- Touchpoints
- Overall experience
- Opportunities for improvement

### 3 · User Flow vs User Journey
What is the difference?

Aspect\tUser Flow\tUser Journey
Meaning\tSteps to complete a task\tThe complete user experience
Main focus\tActions & navigation\tExperience & emotions
Scope\tOne specific task\tThe whole experience
Shows\tScreens, steps, decisions\tStages, goals, pain points
Used to\tMake a task easier\tImprove the overall experience
Example\tHow do I log in?\tThe experience from first hearing about the app to using it again

### 4 · When to use each
When should you use each?

User Flow: to check whether a user can complete a task easily.

{fig('vs-wireflow', 'User flow of screens for a first app launch', '', 'User Flow: screens, actions, a decision point (first launch?) and an alternative path.')}

User Journey: to understand how the user experiences the whole product.

{fig('vs-journey-map', 'Journey map grid', '', 'Journey map: stages (Awareness → Loyalty) × actions, goals, feelings, pain points and opportunities.')}

### 5 · How to answer in an interview
Question: What is the difference between User Flow and User Journey?

You can say it simply:
“User Flow focuses on the steps a user takes to complete a specific task in a product. For example, logging into an app or making a payment.
User Journey focuses on the complete user experience, including their goals, expectations, emotions, and pain points across different stages.
In simple words, User Flow explains how users complete a task, while User Journey explains what users experience throughout their interaction with the product.”

Remember this:
- User Flow = How the user completes a task.
- User Journey = What the user experiences throughout the process.

Using both together helps us find the problems users face and create a better UX design."""

Q2_TE = f"""కాదు, User Flow మరియు Task Flow రెండూ పూర్తిగా ఒకటే కావు. కానీ UX Designలో చాలా సందర్భాల్లో ఒకే అర్థంలో ఉపయోగిస్తారు. రెండింటి మధ్య చిన్న తేడా ఉంది.

### 1 · Task Flow
Task Flow అంటే ఏమిటి?

Task Flow అంటే యూజర్ ఒక నిర్దిష్టమైన పనిని పూర్తి చేయడానికి అనుసరించే దశలు.
ఇందులో సాధారణంగా ఒకే మార్గం (Single Path) ఉంటుంది. యూజర్‌కు ఎలాంటి ప్రత్యామ్నాయాలు లేదా నిర్ణయాలు అవసరం లేని సింపుల్ ప్రాసెస్‌ను చూపిస్తుంది.

{fig('vs-task-flow', 'Task flow: Open App, Enter Mobile Number, Enter OTP, Login Successful', 'ఉదాహరణ: Classic Rummy Appలో Login – ఇది ఒక Taskను పూర్తి చేసే సింపుల్ స్టెప్-బై-స్టెప్ ప్రాసెస్.', 'Example: login in the Classic Rummy app – a simple step-by-step process.')}

### 2 · User Flow
User Flow అంటే ఏమిటి?

User Flow అంటే యూజర్ ఒక Taskను పూర్తి చేసే సమయంలో వివిధ స్క్రీన్‌లు, Actions, Decision Points మరియు Alternative Paths ద్వారా ఎలా ప్రయాణిస్తాడో చూపిస్తుంది.
ఇందులో ఒకటి కంటే ఎక్కువ మార్గాలు ఉండవచ్చు.

{fig('vs-user-flow-branch', 'User flow with OTP decision: correct OTP leads to login success, wrong OTP shows an error and retry', 'ఉదాహరణ: Classic Rummy Appలో Login Flow – సరైన OTP ఇస్తే Login అవుతాడు; తప్పు OTP ఇస్తే Error Message చూపించి మళ్లీ ప్రయత్నించే అవకాశం ఇస్తుంది.', 'Example: login flow in the Classic Rummy app, with correct and wrong OTP paths.')}

ఇక్కడ యూజర్ సరైన OTP ఇస్తే Login అవుతాడు. తప్పు OTP ఇస్తే Error Message చూపించి మళ్లీ ప్రయత్నించే అవకాశం ఇస్తుంది.

### 3 · Task Flow vs User Flow
తేడా

అంశం\tTask Flow\tUser Flow
ఉద్దేశం\tఒక పనిని పూర్తి చేయడం\tయూజర్ చేసే మొత్తం ఇంటరాక్షన్‌ను చూపించడం
మార్గాలు\tసాధారణంగా ఒకే మార్గం\tMultiple Paths ఉండవచ్చు
Decision Points\tసాధారణంగా తక్కువ\tస్పష్టంగా చూపిస్తారు
Error Handling\tసాధారణంగా వివరించరు\tError & Alternative Paths చూపించవచ్చు
Complexity\tSimple\tSimple లేదా Complex

### 4 · ఒక సింపుల్ ఉదాహరణతో గుర్తుంచుకోండి
ATM ఉదాహరణ

ఒక ATMలో డబ్బులు విత్‌డ్రా చేయడం అనుకుందాం.
- Task Flow: ATM Card → PIN → Amount → Cash.
- User Flow: ATM Card → PIN Verification → PIN Correct or Incorrect → Select Withdrawal → Check Balance → Cash Available or Insufficient Balance → Cash Dispensed.

అంటే Task Flowలో ప్రధాన పని ఎలా పూర్తవుతుందో చూస్తాం. User Flowలో యూజర్ తీసుకునే నిర్ణయాలు, ఎదురయ్యే పరిస్థితులు, ప్రత్యామ్నాయ మార్గాలను కూడా చూస్తాం.

### 5 · ఇంటర్వ్యూలో ఎలా చెప్పాలి?
Question: What is the difference between Task Flow and User Flow?

“Task Flow represents the simple steps a user follows to complete a specific task, usually through a single path.
User Flow shows how users interact with the product, including different screens, actions, decision points, and alternative paths.
For example, a Task Flow shows the basic login steps, while a User Flow also covers scenarios like incorrect OTP, error messages, and retry options.”

ముఖ్యమైన విషయం: UX Designలో ఈ పదాల వినియోగం కంపెనీని బట్టి మారవచ్చు. కొన్ని టీమ్‌లు Task Flowను User Flowలోని ఒక సరళమైన రూపంగా పరిగణిస్తాయి. కాబట్టి ఇంటర్వ్యూలో ఈ తేడాను ఉదాహరణతో వివరించడం మంచిది."""

Q2_EN = f"""No, User Flow and Task Flow are not exactly the same, although in UX design they are often used with the same meaning. There is a small difference between them.

### 1 · Task Flow
What is a Task Flow?

A Task Flow is the set of steps a user follows to complete a specific task.
It usually has a single path. It shows a simple process in which the user needs no alternatives or decisions.

{fig('vs-task-flow', 'Task flow for login', '', 'Example: login in the Classic Rummy app – a simple step-by-step process to complete one task.')}

### 2 · User Flow
What is a User Flow?

A User Flow shows how a user moves through different screens, actions, decision points and alternative paths while completing a task.
It can have more than one path.

{fig('vs-user-flow-branch', 'User flow with OTP decision', '', 'Example: login flow in the Classic Rummy app.')}

Here, if the user enters the correct OTP they are logged in. If they enter a wrong OTP, an error message is shown with the option to try again.

### 3 · Task Flow vs User Flow
The difference

Aspect\tTask Flow\tUser Flow
Purpose\tComplete one task\tShow the user’s whole interaction
Paths\tUsually a single path\tCan have multiple paths
Decision points\tUsually few\tShown clearly
Error handling\tUsually not described\tCan show error & alternative paths
Complexity\tSimple\tSimple or complex

### 4 · Remember it with a simple example
ATM example

Imagine withdrawing money from an ATM.
- Task Flow: ATM Card → PIN → Amount → Cash.
- User Flow: ATM Card → PIN Verification → PIN Correct or Incorrect → Select Withdrawal → Check Balance → Cash Available or Insufficient Balance → Cash Dispensed.

So in a Task Flow we see how the main task gets done. In a User Flow we also see the decisions the user makes, the situations they face and the alternative paths.

### 5 · How to answer in an interview
Question: What is the difference between Task Flow and User Flow?

“Task Flow represents the simple steps a user follows to complete a specific task, usually through a single path.
User Flow shows how users interact with the product, including different screens, actions, decision points, and alternative paths.
For example, a Task Flow shows the basic login steps, while a User Flow also covers scenarios like incorrect OTP, error messages, and retry options.”

Important: how these terms are used can vary between companies. Some teams treat a Task Flow as a simpler form of a User Flow, so in an interview it’s good to explain the difference with an example."""

EX1_TE = """Classic Rummy ఉదాహరణలు:
- User Flow: Open App → Login Screen → Enter Mobile Number → OTP Verification → Home Screen (ఒక Task – Login).
- User Journey: Awareness → Consideration → Registration → First Game → Retention (మొత్తం అనుభవం – భావనలతో).

Remember this:
User Flow = How the user completes a task.
User Journey = What the user experiences throughout the process."""
EX1_EN = """Classic Rummy examples:
- User Flow: Open App → Login Screen → Enter Mobile Number → OTP Verification → Home Screen (one task – login).
- User Journey: Awareness → Consideration → Registration → First Game → Retention (the whole experience, with emotions).

Remember this:
User Flow = How the user completes a task.
User Journey = What the user experiences throughout the process."""
EX2_TE = """Classic Rummy Login:
- Task Flow: Open App → Enter Mobile Number → Enter OTP → Login Successful.
- User Flow: Open App → Login Screen → Enter Mobile Number → OTP Verification → Correct OTP (Login Success) / Wrong OTP (Show Error / Retry).

ATM:
- Task Flow: ATM Card → PIN → Amount → Cash.
- User Flow: PIN Correct or Incorrect, Cash Available or Insufficient Balance వంటి నిర్ణయాలతో."""
EX2_EN = """Classic Rummy login:
- Task Flow: Open App → Enter Mobile Number → Enter OTP → Login Successful.
- User Flow: Open App → Login Screen → Enter Mobile Number → OTP Verification → Correct OTP (Login Success) / Wrong OTP (Show Error / Retry).

ATM:
- Task Flow: ATM Card → PIN → Amount → Cash.
- User Flow: adds decisions such as PIN correct or incorrect, cash available or insufficient balance."""

def q(n, en, te, ate, aen, exte, exen):
    return {'questionId': f'vs-{n}', 'questionNumber': n, 'label': f'Vs {n}', 'questionEnglish': en, 'questionTelugu': te,
            'answerTelugu': ate.strip(), 'answerEnglish': aen.strip(), 'exampleTelugu': exte, 'exampleEnglish': exen, 'importantMarkers': []}
parts = [{'partId': 'vs-1', 'partNumber': 1, 'title': 'Flows and journeys', 'subtitle': 'Task Flow · User Flow · User Journey',
  'description': 'తరచుగా గందరగోళం చేసే UX పదాల మధ్య తేడాలు – ఉదాహరణలతో. మూలం: Task Flow Vs User Journey PDF.\n\nDifferences between often-confused UX terms, with examples. Source: the Task Flow Vs User Journey PDF.',
  'questions': [
    q(1, 'What is the difference between User Flow and User Journey?', 'User Flow మరియు User Journey మధ్య తేడా ఏమిటి?', Q1_TE, Q1_EN, EX1_TE, EX1_EN),
    q(2, 'What is the difference between Task Flow and User Flow?', 'Task Flow మరియు User Flow ఒకటేనా? తేడా ఏమిటి?', Q2_TE, Q2_EN, EX2_TE, EX2_EN)],
  'revisionHeaders': ['Concept', 'Remember'],
  'revision': [{'cells': c} for c in [['User Flow', 'How the user completes a task – screens, actions, decisions, errors'], ['User Journey', 'What the user experiences – stages, goals, emotions, pain points'], ['Task Flow', 'Simple steps for one task – usually a single path']]],
  'vocabulary': [], 'extras': []}]
(ROOT / 'data/vs.js').write_text('/* Vs tab – from Task_Flow_Vs_User_Journey.pdf. Telugu first, English behind the button. */\nwindow.BOOK_VS_PARTS = ' + json.dumps(parts, ensure_ascii=False, indent=1) + ';\n')
(ROOT / 'data/raw/vs.json').write_text(json.dumps(parts, ensure_ascii=False, indent=1))
print('ok')
